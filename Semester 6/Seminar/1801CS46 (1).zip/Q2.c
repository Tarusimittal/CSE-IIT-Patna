#include <stdio.h>
#include <stdlib.h>

int THM, TST;

// Function to find minimum of 2 nos
int min(int a, int b) {
	return (a < b)? a: b;
}

/* Comparator for Q-Sort */
int compare (const void * a, const void * b) {
	int A = *((int*)a);
	int B = *((int*)b);
	return ( A - B );
}

void slook(int n_cyl, int head_pos, int seek, int n_req, int disk[]) {
	qsort(disk, n_req, sizeof(int), compare);
	int left_max = ( disk[0] <= head_pos )? head_pos - disk[0]: -1;
	int right_max = ( disk[n_req - 1] >= head_pos )? disk[n_req - 1] - head_pos: - 1;
	if ( left_max == -1 ) THM = right_max;
	else if ( right_max == -1 ) THM = left_max;
	else THM = min(2 * left_max + right_max, 2 * right_max + left_max);
	TST = THM * seek;
}

int main() {
	int n_cyl, head_pos, n_req, seek;

	printf("Enter Number of Cylinders: ");
	scanf("%d", &n_cyl);

	printf("Enter the head position: ");
	scanf("%d", &head_pos);

	printf("Enter the seek time (in ms) for one cylinder movement: ");
	scanf("%d", &seek);

	printf("Enter the number of disk requests: ");
	scanf("%d", &n_req);

	int disk[n_req];
	printf("Enter the requests: \n");
	for (int i = 0; i < n_req; i++) {
		scanf("%d", &disk[i]);
	}

	slook(n_cyl, head_pos, seek, n_req, disk);

	printf("Total Head Movement = %d\nTotal Seek Time = %d ms\n", THM, TST);
}