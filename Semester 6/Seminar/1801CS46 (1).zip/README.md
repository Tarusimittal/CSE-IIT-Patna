#### Name: Shashwat Mahajan
#### Roll Number: 1801CS46

NOTE: Commands are typed like 
```
command
```

## Installing gnuplot for graphs
Install gnuplot for plotting graphs using the following command in the terminal:
```
sudo apt install gnuplot
```

## Problem 1
As written in the question, it is assumed that the seek time to move one cylinder is 5 milliseconds.

### Compilation
```
gcc Q1.c -o Q1
```

### Execution Syntax
```
./Q1
```

### Example 1:
```
./Q1
```
```
Enter Number of Cylinders: 200
Enter the head position: 100
Enter the number of disk requests: 5
Enter the requests: 
23 89 132 42 187

FCFS Disk Scheduling
Total Head Movement = 421
Total Seek Time = 2105 ms

SCAN Disk Scheduling
Total Head Movement = 263
Total Seek Time = 1315 ms

CSCAN Disk Scheduling
Total Head Movement = 176
Total Seek Time = 880 ms

SSTF Disk Scheduling
Total Head Movement = 273
Total Seek Time = 1365 ms

Sorted order of algorithms:
CSCAN SCAN SSTF FCFS
```
FCFS Disk Scheduling Graph
![FCFS]
(FCFS.png)

SSTF Disk Scheduling Graph
![SSTF]
(SSTF.png)

CSCAN Disk Scheduling Graph
![CSCAN]
(CSCAN.png)

SCAN Disk Scheduling Graph
![SCAN]
(SCAN.png)

## Problem 2

### Compilation
```
gcc Q2.c -o Q2
```

### Execution Syntax
```
./Q2
```

### Example 1:
```
./Q2
```
```
Enter Number of Cylinders: 200
Enter the head position: 100
Enter the seek time (in ms) for one cylinder movement: 5
Enter the number of disk requests: 8
Enter the requests: 
98 183 37 122 14 124 65 67
Total Head Movement = 252
Total Seek Time = 1260 ms
```